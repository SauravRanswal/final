package com.ignouproject.farmersbuddy;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FarmersbuddyApplication {

	public static void main(String[] args) {
		SpringApplication.run(FarmersbuddyApplication.class, args);
	}

}
